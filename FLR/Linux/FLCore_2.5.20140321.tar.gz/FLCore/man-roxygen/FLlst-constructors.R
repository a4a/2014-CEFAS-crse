#' @section Constructor:
#' A constructor method exists for this class that can take named arguments for
#' any of the list elements.
